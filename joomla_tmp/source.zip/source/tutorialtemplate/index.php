<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
<meta charset="utf-8">

<!--[if IE]><![endif]-->
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<?php include_once(JPATH_ROOT . "/templates/" . $this->template . '/includes/sections/setup.php'); ?>
<?php include_once(JPATH_ROOT . "/templates/" . $this->template . '/includes/sections/head.php'); ?>

</head>

<?php include_once(JPATH_ROOT . "/templates/" . $this->template . '/includes/sections/header.php'); ?>



       <section id="main" class="clearfix">
           
           <jdoc:include type="component" />


       </section>
       


       
       
       
       
        
<?php include_once(JPATH_ROOT . "/templates/" . $this->template . '/includes/sections/footer.php'); ?>


<?php include_once(JPATH_ROOT . "/templates/" . $this->template . '/includes/sections/scripts.php'); ?>

</body>
</html>