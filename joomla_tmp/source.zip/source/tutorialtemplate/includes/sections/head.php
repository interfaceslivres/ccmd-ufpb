
<link rel="stylesheet" href="<?php echo JURI::base()."templates/".$this->template."/css/".$style;?>.css">
<link rel="stylesheet" href="<?php echo JURI::base()."templates/".$this->template;?>/css/prettyPhoto.css">

<script src="<?php echo JURI::base()."templates/".$this->template; ?>/includes/scripts/modernizr-1.5.min.js"></script>