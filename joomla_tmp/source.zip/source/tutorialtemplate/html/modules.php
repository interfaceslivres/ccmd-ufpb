<?php

function modChrome_raw($module, &$params, &$attribs)
{	
	echo $module->content;
}

?>