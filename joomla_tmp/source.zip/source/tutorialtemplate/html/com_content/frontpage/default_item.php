
    <?php echo JFilterOutput::ampReplace($this->item->text); ?>
 

